// Android shim: emulates chrome.storage.local + chrome.runtime for popup.js
(function () {
  var store = {};
  try { store = JSON.parse(SSPanel.getStore() || '{}') || {}; } catch (e) { store = {}; }
  function pick(keys) {
    var out = {};
    if (keys == null) return JSON.parse(JSON.stringify(store));
    if (typeof keys === 'string') keys = [keys];
    if (Array.isArray(keys)) keys.forEach(function (k) { if (k in store) out[k] = store[k]; });
    else Object.keys(keys).forEach(function (k) { out[k] = (k in store) ? store[k] : keys[k]; });
    return out;
  }
  window.chrome = {
    runtime: {
      lastError: null,
      sendMessage: function (msg, cb) {
        var res = { ok: true, lastHeartbeat: Number(SSPanel.lastReady()) || 0, activeTabs: [] };
        if (cb) setTimeout(function () { cb(res); }, 0);
      }
    },
    storage: {
      local: {
        get: function (keys, cb) { var r = pick(keys); if (cb) setTimeout(function () { cb(r); }, 0); },
        set: function (val, cb) {
          Object.keys(val || {}).forEach(function (k) { store[k] = val[k]; });
          try { SSPanel.setStore(JSON.stringify(store)); } catch (e) {}
          if (cb) setTimeout(function () { cb(); }, 0);
        }
      }
    }
  };
})();
