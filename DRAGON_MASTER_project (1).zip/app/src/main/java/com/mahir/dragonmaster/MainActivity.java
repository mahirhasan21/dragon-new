package com.mahir.dragonmaster;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class MainActivity extends Activity {

    // ------------------------------------------------------------------ constants

    private static final int REQ_FILE = 101;
    private static final int REQ_MEDIA = 102;
    private static final int REQ_PERM = 103;
    private static final long MAX_MEDIA_BYTES = 40L * 1024L * 1024L;
    private static final int CHUNK = 3 * 128 * 1024;

    private static final String APP_TITLE = "DRAGON MASTER";
    private static final String APP_SUB = "মাহির ব্রাউজার কল";

    private static final String[] SITE_NAMES = {
            "Facebook", "Messenger", "Instagram", "WhatsApp Web", "Telegram Web",
            "Google Meet (beta)", "Discord (beta)"
    };
    private static final String[] SITE_URLS = {
            "https://www.facebook.com/",
            "https://www.messenger.com/",
            "https://www.instagram.com/",
            "https://web.whatsapp.com/",
            "https://web.telegram.org/k/",
            "https://meet.google.com/",
            "https://discord.com/app"
    };
    private static final String[] ALLOWED_HOSTS = {
            "facebook.com", "messenger.com", "instagram.com", "whatsapp.com",
            "telegram.org", "meet.google.com", "discord.com"
    };

    // name, bg, bar, card, accent, text, dim
    private static final String[][] THEMES = {
            {"Dragon Green", "#04121a", "#08202c", "#0e2f3f", "#5ff5d6", "#FFFFFF", "#8aa7b3"},
            {"Fire Red", "#140808", "#241010", "#361818", "#ff5a4d", "#FFFFFF", "#b99a97"},
            {"Ocean Blue", "#06101f", "#0b1c33", "#12294a", "#4da3ff", "#FFFFFF", "#8fa3bf"},
            {"Light", "#f2f5f7", "#ffffff", "#e3eaee", "#0a8f72", "#10222b", "#5d727c"}
    };
    private static final String[] PRESET_NAMES = {"Normal", "Loud", "Max", "Voice Clear"};
    private static final int[] PRESET_GAINS = {1, 6, 12, 3};

    private static final String ERROR_HTML = "<html><body style='background:#04121a;color:#fff;"
            + "font-family:sans-serif;text-align:center;padding:48px 20px'>"
            + "<h2 style='color:#5ff5d6'>DRAGON MASTER</h2>"
            + "<p>পেজ লোড হয়নি। ইন্টারনেট চেক করুন।</p><p>Page failed to load. Check internet.</p>"
            + "<p>⋮ → 🔄 Reload</p></body></html>";

    // call state survives recreate()
    private static boolean sCallActive = false;
    private static long sCallStart = 0;
    private static boolean sMicMuted = false;
    private static long sLastStop = 0;

    // ------------------------------------------------------------------ fields

    private SharedPreferences prefs;
    private File mixDir;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private int themeIdx;
    private boolean bn;
    private int cBg, cBar, cCard, cAccent, cText, cDim;

    private FrameLayout root;
    private FrameLayout content;
    private ProgressBar progress;
    private TextView tvChip;
    private TextView[] navItems = new TextView[5];
    private int page = 0; // 0 home, 1 mic, 2 mixer, 3 web, 4 settings

    private ScrollView homeView;
    private WebView micPanel;
    private WebView mixerPanel;
    private LinearLayout webArea;
    private ScrollView settingsView;
    private LinearLayout settingsBox;

    private TextView tvMic, tvBat, tvNet, tvCall;

    // browser
    private static class Tab {
        WebView web;
        String title = "New";
    }

    private final List<Tab> tabs = new ArrayList<Tab>();
    private int curTab = -1;
    private WebView web;
    private FrameLayout webFrame;
    private LinearLayout tabStrip;
    private HorizontalScrollView tabScroll;
    private EditText urlBox;
    private String defaultUa;
    private boolean desktop;

    // floating call controls
    private LinearLayout fcall;
    private TextView fcTimer, fcMic;
    private int presetIdx = 0;

    // lock
    private FrameLayout lockView;
    private TextView lockDots, lockMsg;
    private final StringBuilder pinBuf = new StringBuilder();
    private int wrongCount = 0;
    private long lockUntil = 0;

    // fullscreen video
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;

    private String mixerState = "{\"items\":[],\"mics\":[],\"devices\":[]}";
    private long lastReady = 0;
    private String injectJs = null;

    private PermissionRequest pendingRequest;
    private ValueCallback<Uri[]> pendingFile;

    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private final AudioManager.OnAudioFocusChangeListener focusListener =
            new AudioManager.OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int change) {
                    resumeCallAudio();
                }
            };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("PREFS", MODE_PRIVATE);
        mixDir = new File(getFilesDir(), "mixer");
        mixDir.mkdirs();
        desktop = prefs.getBoolean("desktop", false);
        bn = prefs.getBoolean("bn", true);
        themeIdx = prefs.getInt("theme", 0);
        if (themeIdx < 0 || themeIdx >= THEMES.length) themeIdx = 0;
        String[] th = THEMES[themeIdx];
        cBg = Color.parseColor(th[1]);
        cBar = Color.parseColor(th[2]);
        cCard = Color.parseColor(th[3]);
        cAccent = Color.parseColor(th[4]);
        cText = Color.parseColor(th[5]);
        cDim = Color.parseColor(th[6]);

        getWindow().setStatusBarColor(cBar);
        getWindow().setNavigationBarColor(cBar);
        if (themeIdx == 3) {
            View d = getWindow().getDecorView();
            d.setSystemUiVisibility(d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        applyWindowFlags();

        buildUi();

        ArrayList<String> want = new ArrayList<String>();
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) want.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33
                && !hasPerm(Manifest.permission.POST_NOTIFICATIONS)) {
            want.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!want.isEmpty()) requestPermissions(want.toArray(new String[0]), REQ_PERM + 1);

        restoreTabs();
        showPage(0);

        if (prefs.getString("pinHash", null) != null) showLock();
        showSplash();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        resumeCallAudio();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(tick);
        saveTabs();
        super.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (prefs.getString("pinHash", null) != null && sLastStop > 0
                && System.currentTimeMillis() - sLastStop > 30000) {
            showLock();
        }
    }

    @Override
    protected void onStop() {
        sLastStop = System.currentTimeMillis();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        try {
            if (audioManager != null && !sCallActive) {
                if (Build.VERSION.SDK_INT >= 26 && focusRequest != null) {
                    audioManager.abandonAudioFocusRequest(focusRequest);
                } else {
                    audioManager.abandonAudioFocus(focusListener);
                }
            }
        } catch (Exception ignored) {
        }
        for (Tab t : tabs) t.web.destroy();
        if (micPanel != null) micPanel.destroy();
        if (mixerPanel != null) mixerPanel.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (lockView != null && lockView.getVisibility() == View.VISIBLE) {
            // locked: ignore
        } else if (page == 3 && web != null && web.canGoBack()) {
            web.goBack();
        } else if (page != 0) {
            showPage(0);
        } else {
            new AlertDialog.Builder(this)
                    .setTitle(APP_TITLE)
                    .setMessage(t("অ্যাপ থেকে বের হতে চান?", "Exit the app?"))
                    .setPositiveButton(t("হ্যাঁ", "Yes"), (d, w) -> finish())
                    .setNegativeButton(t("না", "No"), null)
                    .show();
        }
    }

    // ------------------------------------------------------------------ helpers

    private String t(String bnText, String enText) {
        return bn ? bnText : enText;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (a << 24);
    }

    private GradientDrawable round(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(radiusDp));
        g.setColor(fill);
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private TextView btn(String text, final View.OnClickListener l) {
        TextView tv = label(text, 14, cText, true);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(10), dp(12), dp(10), dp(12));
        GradientDrawable bg = round(cCard, alpha(cAccent, 0x66), 14);
        tv.setBackground(new RippleDrawable(
                ColorStateList.valueOf(alpha(cAccent, 0x55)), bg, null));
        tv.setClickable(true);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
                        l.onClick(v);
                    }
                }).start();
            }
        });
        return tv;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackground(round(cCard, alpha(cAccent, 0x40), 16));
        return c;
    }

    private LinearLayout.LayoutParams lpW(float w, int margin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, w);
        p.setMargins(dp(margin), dp(margin), dp(margin), dp(margin));
        return p;
    }

    private LinearLayout.LayoutParams lpFull(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(topMargin);
        return p;
    }

    private TextView section(String text) {
        TextView tv = label(text, 13, cAccent, true);
        tv.setPadding(dp(4), dp(16), 0, dp(6));
        return tv;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void applyWindowFlags() {
        if (prefs.getBoolean("keepOn", true)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        if (prefs.getBoolean("secure", false)) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
    }

    private AudioManager am() {
        if (audioManager == null) audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        return audioManager;
    }

    // ------------------------------------------------------------------ main UI

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(cBg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        // top bar
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(cBar);

        TextView menuBtn = label("☰", 24, cAccent, false);
        menuBtn.setGravity(Gravity.CENTER);
        menuBtn.setPadding(dp(16), 0, dp(14), 0);
        menuBtn.setOnClickListener(v -> showSites());
        bar.addView(menuBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        TextView title = label(APP_TITLE, 17, cText, true);
        title.setSingleLine(true);
        titleCol.addView(title);
        TextView sub = label(APP_SUB, 12, cAccent, false);
        sub.setSingleLine(true);
        titleCol.addView(sub);
        bar.addView(titleCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        tvChip = label("⏱ 00:00", 12, cBar, true);
        tvChip.setPadding(dp(10), dp(4), dp(10), dp(4));
        tvChip.setBackground(round(cAccent, 0, 12));
        tvChip.setVisibility(View.GONE);
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipLp.rightMargin = dp(6);
        bar.addView(tvChip, chipLp);

        TextView more = label("⋮", 26, cAccent, false);
        more.setGravity(Gravity.CENTER);
        more.setPadding(dp(14), 0, dp(16), 0);
        more.setOnClickListener(v -> showMore());
        bar.addView(more, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));

        col.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(cAccent));
        progress.setVisibility(View.GONE);
        col.addView(progress, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

        // content pages
        content = new FrameLayout(this);
        homeView = (ScrollView) buildHome();
        micPanel = newPanelWebView();
        mixerPanel = newPanelWebView();
        buildWebArea();
        settingsView = new ScrollView(this);
        settingsView.setBackgroundColor(cBg);
        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setPadding(dp(14), dp(10), dp(14), dp(24));
        settingsView.addView(settingsBox);

        FrameLayout.LayoutParams full = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        content.addView(homeView, full);
        content.addView(micPanel, full);
        content.addView(mixerPanel, full);
        content.addView(webArea, full);
        content.addView(settingsView, full);
        col.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        col.addView(buildNav(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));

        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        buildFloatingCall();
        buildLock();
        setContentView(root);
    }

    private View buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(cBar);
        String[] icons = {"🏠", "🎤", "🎚", "🌐", "⚙"};
        String[] names = {t("হোম", "Home"), t("মাইক", "Mic"), t("মিক্সার", "Mixer"),
                t("ওয়েব", "Web"), t("সেটিং", "Settings")};
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            TextView item = new TextView(this);
            item.setText(icons[i] + "\n" + names[i]);
            item.setTextSize(11);
            item.setGravity(Gravity.CENTER);
            item.setTextColor(cDim);
            item.setClickable(true);
            item.setBackground(new RippleDrawable(
                    ColorStateList.valueOf(alpha(cAccent, 0x40)), null, null));
            item.setOnClickListener(v -> showPage(idx));
            navItems[i] = item;
            nav.addView(item, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        return nav;
    }

    private void showPage(int p) {
        page = p;
        homeView.setVisibility(p == 0 ? View.VISIBLE : View.GONE);
        micPanel.setVisibility(p == 1 ? View.VISIBLE : View.GONE);
        mixerPanel.setVisibility(p == 2 ? View.VISIBLE : View.GONE);
        webArea.setVisibility(p == 3 ? View.VISIBLE : View.GONE);
        settingsView.setVisibility(p == 4 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 5; i++) {
            navItems[i].setTextColor(i == p ? cAccent : cDim);
            navItems[i].setTypeface(i == p ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
        if (p == 1) micPanel.loadUrl("file:///android_asset/popup/popup.html");
        if (p == 2) mixerPanel.loadUrl("file:///android_asset/popup/mixer.html");
        if (p == 4) buildSettings();
        if (p != 3) progress.setVisibility(View.GONE);
        updateStatus();
    }

    // ------------------------------------------------------------------ splash

    private void showSplash() {
        final FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(cBg);
        sp.setClickable(true);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.ic_launcher);
        l.addView(iv, new LinearLayout.LayoutParams(dp(110), dp(110)));
        TextView n = label(APP_TITLE, 26, cAccent, true);
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(16), 0, dp(4));
        l.addView(n);
        TextView s = label(APP_SUB, 14, cDim, false);
        s.setGravity(Gravity.CENTER);
        l.addView(s);
        sp.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(sp, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        sp.animate().alpha(0f).setStartDelay(1100).setDuration(400).withEndAction(new Runnable() {
            @Override
            public void run() {
                root.removeView(sp);
            }
        }).start();
    }

    // ------------------------------------------------------------------ home / dashboard

    private TextView statusCard(LinearLayout row, String emoji, String title) {
        LinearLayout c = card();
        c.addView(label(emoji + " " + title, 12, cDim, false));
        TextView v = label("--", 17, cAccent, true);
        v.setPadding(0, dp(4), 0, 0);
        c.addView(v);
        row.addView(c, lpW(1f, 4));
        return v;
    }

    private View buildHome() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(cBg);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(24));

        LinearLayout banner = card();
        banner.setOrientation(LinearLayout.HORIZONTAL);
        banner.setGravity(Gravity.CENTER_VERTICAL);
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.ic_launcher);
        banner.addView(iv, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(14), 0, 0, 0);
        tx.addView(label(APP_TITLE, 21, cAccent, true));
        tx.addView(label(APP_SUB, 13, cDim, false));
        banner.addView(tx);
        c.addView(banner, lpFull(0));

        c.addView(section(t("স্ট্যাটাস", "STATUS")));
        LinearLayout r1 = new LinearLayout(this);
        tvMic = statusCard(r1, "🎤", t("মাইক", "Mic"));
        tvBat = statusCard(r1, "🔋", t("ব্যাটারি", "Battery"));
        c.addView(r1);
        LinearLayout r2 = new LinearLayout(this);
        tvNet = statusCard(r2, "📶", t("নেট", "Network"));
        tvCall = statusCard(r2, "⏱", t("কলের সময়", "Call time"));
        c.addView(r2);

        c.addView(section(t("সাউন্ড প্রিসেট (১ ট্যাপ)", "SOUND PRESETS (1 TAP)")));
        LinearLayout pr = new LinearLayout(this);
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            pr.addView(btn(PRESET_NAMES[i] + "\n×" + PRESET_GAINS[i], v -> applyPreset(idx, true)),
                    lpW(1f, 3));
        }
        c.addView(pr);

        c.addView(section(t("দ্রুত ওয়েব", "QUICK SITES")));
        LinearLayout row = null;
        for (int i = 0; i < SITE_NAMES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                c.addView(row);
            }
            final String url = SITE_URLS[i];
            row.addView(btn("🌐 " + SITE_NAMES[i], v -> openSite(url)), lpW(1f, 3));
            if (i == SITE_NAMES.length - 1 && i % 2 == 0) {
                row.addView(new View(this), lpW(1f, 3));
            }
        }
        sv.addView(c);
        return sv;
    }

    private void openSite(String url) {
        showPage(3);
        if (web != null) web.loadUrl(url);
    }

    private String fmt(long ms) {
        long s = Math.max(0, ms / 1000);
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, sec);
        return String.format("%02d:%02d", m, sec);
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateStatus();
            handler.postDelayed(this, 1000);
        }
    };

    private void updateStatus() {
        String ct = sCallActive ? fmt(System.currentTimeMillis() - sCallStart) : "--:--";
        if (tvChip != null) {
            tvChip.setText("⏱ " + ct);
            tvChip.setVisibility(sCallActive ? View.VISIBLE : View.GONE);
        }
        if (fcTimer != null) fcTimer.setText(ct);
        if (page != 0 || tvMic == null) return;
        String mic;
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) mic = "✗ " + t("অনুমতি নেই", "No permission");
        else if (sMicMuted) mic = "🔇 Muted";
        else if (sCallActive) mic = "● Live";
        else mic = "✓ Ready";
        tvMic.setText(mic);
        tvCall.setText(ct);
        try {
            Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) {
                int lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                tvBat.setText(lvl < 0 ? "--" : (lvl * 100 / sc) + "%");
            }
        } catch (Exception ignored) {
        }
        String net = t("নেই", "Offline");
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc != null) {
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) net = "Wi-Fi";
                else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) net = "Mobile";
                else net = "Online";
            }
        } catch (Exception ignored) {
        }
        tvNet.setText(net);
    }

    // ------------------------------------------------------------------ presets

    private void applyPreset(int i, boolean notify) {
        presetIdx = i;
        try {
            JSONObject st = new JSONObject(storeJson());
            JSONObject cfg = st.optJSONObject("micMaximizerConfig");
            if (cfg == null) cfg = new JSONObject();
            cfg.put("listenGain", PRESET_GAINS[i]);
            st.put("micMaximizerConfig", cfg);
            prefs.edit().putString("store", st.toString()).apply();
            for (Tab tb : tabs) {
                tb.web.evaluateJavascript("window.__ssPush&&window.__ssPush();", null);
            }
        } catch (Exception ignored) {
        }
        if (notify) toast("🎛 " + PRESET_NAMES[i] + " (×" + PRESET_GAINS[i] + ")");
    }

    // ------------------------------------------------------------------ floating call controls

    private TextView fcBtn(String text, View.OnClickListener l) {
        TextView tv = label(text, 20, cText, false);
        tv.setGravity(Gravity.CENTER);
        tv.setClickable(true);
        tv.setOnClickListener(l);
        return tv;
    }

    private void buildFloatingCall() {
        fcall = new LinearLayout(this);
        fcall.setOrientation(LinearLayout.VERTICAL);
        fcall.setGravity(Gravity.CENTER_HORIZONTAL);
        fcall.setPadding(dp(6), dp(8), dp(6), dp(8));
        fcall.setBackground(round(alpha(cCard, 0xEE), alpha(cAccent, 0x99), 20));
        fcall.setElevation(dp(10));
        fcall.setVisibility(View.GONE);

        fcTimer = label("00:00", 11, cAccent, true);
        fcTimer.setGravity(Gravity.CENTER);
        fcall.addView(fcTimer);

        fcMic = fcBtn("🎤", v -> toggleMic());
        fcall.addView(fcMic, new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("🔉", v -> adjustVol(false)), new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("🔊", v -> adjustVol(true)), new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("🎛", v -> {
            applyPreset((presetIdx + 1) % 4, true);
        }), new LinearLayout.LayoutParams(dp(46), dp(44)));
        fcall.addView(fcBtn("⏹", v -> endCall()), new LinearLayout.LayoutParams(dp(46), dp(44)));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);
        lp.rightMargin = dp(6);
        root.addView(fcall, lp);
    }

    private void toggleMic() {
        sMicMuted = !sMicMuted;
        try {
            am().setMicrophoneMute(sMicMuted);
        } catch (Exception ignored) {
        }
        updateCallUi();
        toast(sMicMuted ? "🔇 Mic OFF" : "🎤 Mic ON");
    }

    private void adjustVol(boolean up) {
        try {
            int dir = up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
            am().adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI);
            am().adjustStreamVolume(AudioManager.STREAM_VOICE_CALL, dir, 0);
        } catch (Exception ignored) {
        }
    }

    private void updateCallUi() {
        if (fcall != null) fcall.setVisibility(sCallActive ? View.VISIBLE : View.GONE);
        if (fcMic != null) fcMic.setText(sMicMuted ? "🔇" : "🎤");
        updateStatus();
    }

    private void callStarted() {
        if (sCallActive) return;
        sCallActive = true;
        sCallStart = System.currentTimeMillis();
        startCallAudio();
        try {
            Intent si = new Intent(this, CallService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
            else startService(si);
        } catch (Exception ignored) {
        }
        int auto = prefs.getInt("autoPreset", -1);
        if (auto >= 0 && auto < 4) applyPreset(auto, false);
        updateCallUi();
    }

    private void endCall() {
        sCallActive = false;
        sMicMuted = false;
        try {
            am().setMicrophoneMute(false);
        } catch (Exception ignored) {
        }
        try {
            stopService(new Intent(this, CallService.class));
        } catch (Exception ignored) {
        }
        updateCallUi();
    }

    // ------------------------------------------------------------------ browser area

    private void buildWebArea() {
        webArea = new LinearLayout(this);
        webArea.setOrientation(LinearLayout.VERTICAL);
        webArea.setBackgroundColor(cBg);

        // tab strip
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setGravity(Gravity.CENTER_VERTICAL);
        tabRow.setBackgroundColor(cBar);
        tabScroll = new HorizontalScrollView(this);
        tabScroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this);
        tabStrip.setOrientation(LinearLayout.HORIZONTAL);
        tabScroll.addView(tabStrip);
        tabRow.addView(tabScroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView plus = label("＋", 22, cAccent, true);
        plus.setGravity(Gravity.CENTER);
        plus.setPadding(dp(14), dp(4), dp(14), dp(4));
        plus.setOnClickListener(v -> createTab("https://www.google.com/"));
        tabRow.addView(plus);
        webArea.addView(tabRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        // address bar
        LinearLayout ab = new LinearLayout(this);
        ab.setOrientation(LinearLayout.HORIZONTAL);
        ab.setGravity(Gravity.CENTER_VERTICAL);
        ab.setBackgroundColor(cBar);
        ab.setPadding(dp(6), dp(2), dp(6), dp(6));
        TextView back = label("◀", 18, cAccent, false);
        back.setPadding(dp(10), dp(6), dp(10), dp(6));
        back.setOnClickListener(v -> {
            if (web != null && web.canGoBack()) web.goBack();
        });
        TextView fwd = label("▶", 18, cAccent, false);
        fwd.setPadding(dp(10), dp(6), dp(10), dp(6));
        fwd.setOnClickListener(v -> {
            if (web != null && web.canGoForward()) web.goForward();
        });
        ab.addView(back);
        ab.addView(fwd);

        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextSize(13);
        urlBox.setTextColor(cText);
        urlBox.setHintTextColor(cDim);
        urlBox.setHint(t("সার্চ বা লিংক লিখুন", "Search or type link"));
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setBackground(round(cCard, alpha(cAccent, 0x40), 18));
        urlBox.setPadding(dp(14), dp(6), dp(14), dp(6));
        urlBox.setOnEditorActionListener((v, actionId, ev) -> {
            goToUrlBox();
            return true;
        });
        ab.addView(urlBox, new LinearLayout.LayoutParams(0, dp(38), 1f));

        TextView star = label("⭐", 18, cAccent, false);
        star.setPadding(dp(10), dp(6), dp(6), dp(6));
        star.setOnClickListener(v -> addBookmarkCurrent());
        TextView rl = label("🔄", 18, cAccent, false);
        rl.setPadding(dp(6), dp(6), dp(8), dp(6));
        rl.setOnClickListener(v -> reloadPage());
        ab.addView(star);
        ab.addView(rl);
        webArea.addView(ab, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webFrame = new FrameLayout(this);
        webArea.addView(webFrame, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private void goToUrlBox() {
        String q = urlBox.getText().toString().trim();
        if (q.isEmpty() || web == null) return;
        String url;
        if (q.startsWith("http://") || q.startsWith("https://")) {
            url = q;
        } else if (q.contains(" ") || !q.contains(".")) {
            url = "https://www.google.com/search?q=" + Uri.encode(q);
        } else {
            url = "https://" + q;
        }
        web.loadUrl(url);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
        urlBox.clearFocus();
    }

    private Tab createTab(String url) {
        if (tabs.size() >= 8) {
            toast(t("সর্বোচ্চ ৮টা ট্যাব", "Max 8 tabs"));
            return null;
        }
        WebView w = new WebView(this);
        setupWebView(w);
        Tab tb = new Tab();
        tb.web = w;
        tabs.add(tb);
        webFrame.addView(w, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        selectTab(tabs.size() - 1);
        w.loadUrl(url);
        return tb;
    }

    private void selectTab(int i) {
        curTab = i;
        for (int j = 0; j < tabs.size(); j++) {
            tabs.get(j).web.setVisibility(j == i ? View.VISIBLE : View.GONE);
        }
        web = tabs.get(i).web;
        progress.setVisibility(View.GONE);
        String u = web.getUrl();
        if (u != null && !urlBox.hasFocus()) urlBox.setText(u);
        rebuildTabStrip();
    }

    private void closeTab(int i) {
        if (tabs.size() <= 1) {
            web.loadUrl(SITE_URLS[1]);
            return;
        }
        Tab tb = tabs.remove(i);
        webFrame.removeView(tb.web);
        tb.web.destroy();
        selectTab(Math.min(i, tabs.size() - 1));
    }

    private void rebuildTabStrip() {
        tabStrip.removeAllViews();
        for (int i = 0; i < tabs.size(); i++) {
            final int idx = i;
            LinearLayout chip = new LinearLayout(this);
            chip.setOrientation(LinearLayout.HORIZONTAL);
            chip.setGravity(Gravity.CENTER_VERTICAL);
            boolean on = i == curTab;
            chip.setBackground(round(on ? cCard : cBar, on ? cAccent : alpha(cDim, 0x55), 14));
            chip.setPadding(dp(10), dp(4), dp(4), dp(4));
            String ttl = tabs.get(i).title;
            if (ttl == null || ttl.isEmpty()) ttl = "New";
            if (ttl.length() > 14) ttl = ttl.substring(0, 14) + "…";
            TextView name = label(ttl, 12, on ? cAccent : cText, on);
            name.setOnClickListener(v -> selectTab(idx));
            chip.addView(name);
            TextView x = label("✕", 12, cDim, false);
            x.setPadding(dp(8), dp(2), dp(8), dp(2));
            x.setOnClickListener(v -> closeTab(idx));
            chip.addView(x);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), dp(5), dp(2), dp(5));
            tabStrip.addView(chip, lp);
        }
    }

    private void saveTabs() {
        try {
            JSONArray a = new JSONArray();
            for (Tab tb : tabs) {
                String u = tb.web.getUrl();
                if (u != null && u.startsWith("http")) a.put(u);
            }
            prefs.edit().putString("tabs", a.toString()).putInt("curTab", Math.max(curTab, 0)).apply();
        } catch (Exception ignored) {
        }
    }

    private void restoreTabs() {
        ArrayList<String> urls = new ArrayList<String>();
        try {
            JSONArray a = new JSONArray(prefs.getString("tabs", "[]"));
            for (int i = 0; i < a.length() && i < 8; i++) urls.add(a.getString(i));
        } catch (Exception ignored) {
        }
        if (urls.isEmpty()) urls.add(SITE_URLS[1]);
        for (String u : urls) createTab(u);
        int c = prefs.getInt("curTab", 0);
        if (c >= 0 && c < tabs.size()) selectTab(c);
    }

    private void reloadPage() {
        if (web == null) return;
        String u = web.getUrl();
        if (u == null || !u.startsWith("http")) {
            web.loadUrl(SITE_URLS[1]);
        } else {
            web.reload();
        }
    }

    // ------------------------------------------------------------------ WebViews

    private void applyUa(WebView w) {
        String ua = defaultUa == null ? "" : defaultUa;
        ua = ua.replace("; wv", "");
        if (desktop) {
            ua = ua.replaceAll("\\(Linux; Android[^)]*\\)", "(X11; Linux x86_64)").replace(" Mobile", "");
        }
        WebSettings s = w.getSettings();
        s.setUserAgentString(ua);
        s.setUseWideViewPort(desktop);
        s.setLoadWithOverviewMode(desktop);
    }

    private void setupWebView(final WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setTextZoom(prefs.getInt("zoom", 100));
        if (defaultUa == null) defaultUa = s.getUserAgentString();
        applyUa(w);

        w.setBackgroundColor(cBg);
        w.setTag(Boolean.FALSE);
        w.addJavascriptInterface(new MainBridge(), "SSBridge");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                return !(u.startsWith("http://") || u.startsWith("https://"));
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    view.loadDataWithBaseURL(null, ERROR_HTML, "text/html", "UTF-8", null);
                }
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap icon) {
                view.setTag(Boolean.FALSE);
                inject(view);
                if (view == web && url != null && url.startsWith("http") && !urlBox.hasFocus()) {
                    urlBox.setText(url);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (url != null && url.startsWith("http")) {
                    addHistory(view.getTitle(), url);
                    if (view == web && !urlBox.hasFocus()) urlBox.setText(url);
                }
                inject(view);
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                if (view == web && page == 3) {
                    progress.setProgress(p);
                    progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
                if (p >= 30 && !Boolean.TRUE.equals(view.getTag())) {
                    view.setTag(Boolean.TRUE);
                    inject(view);
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                for (Tab tb : tabs) {
                    if (tb.web == view) {
                        tb.title = title;
                        rebuildTabStrip();
                        break;
                    }
                }
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                root.addView(v, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePermission(request);
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (pendingFile != null) pendingFile.onReceiveValue(null);
                pendingFile = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    pendingFile = null;
                    return false;
                }
                return true;
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                if (url.startsWith("blob:") || url.startsWith("data:")) {
                    toast(t("এই ডাউনলোড সাপোর্ট করে না", "This download is not supported"));
                    return;
                }
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    r.setMimeType(mime);
                    String ck = CookieManager.getInstance().getCookie(url);
                    if (ck != null) r.addRequestHeader("cookie", ck);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    String fn = URLUtil.guessFileName(url, cd, mime);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fn);
                    ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                    toast("Downloading: " + fn);
                } catch (Exception e) {
                    toast("Download failed");
                }
            }
        });
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        getWindow().getDecorView().setSystemUiVisibility(
                themeIdx == 3 ? View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : 0);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
    }

    private WebView newPanelWebView() {
        WebView p = new WebView(this);
        WebSettings s = p.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        p.setBackgroundColor(Color.parseColor("#04121a"));
        p.addJavascriptInterface(new PanelBridge(), "SSPanel");
        p.setWebViewClient(new WebViewClient());
        p.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handlePermission(request);
                    }
                });
            }
        });
        return p;
    }

    private boolean hostAllowed(String url) {
        if (url == null) return false;
        String host;
        try {
            host = Uri.parse(url).getHost();
        } catch (Exception e) {
            return false;
        }
        if (host == null) return false;
        for (String h : ALLOWED_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private String readAsset(String name) {
        try {
            InputStream in = getAssets().open(name);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void inject(WebView view) {
        if (view == null || !hostAllowed(view.getUrl())) return;
        if (injectJs == null) {
            injectJs = readAsset("bridge.js") + "\n;" + readAsset("core/injector.js")
                    + "\n;" + readAsset("mixer.js") + "\n;";
        }
        view.evaluateJavascript(injectJs
                + "window.__ssMixer&&window.__ssMixer.cmd({t:'lib',items:" + libJson() + "});", null);
    }

    private void runInMain(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(js, null);
            }
        });
    }

    // ------------------------------------------------------------------ bookmarks / history

    private JSONArray loadList(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void addHistory(String name, String url) {
        try {
            JSONArray a = loadList("history");
            if (a.length() > 0 && url.equals(a.getJSONObject(a.length() - 1).optString("u"))) return;
            JSONObject o = new JSONObject();
            o.put("n", name == null || name.isEmpty() ? url : name);
            o.put("u", url);
            a.put(o);
            JSONArray out = new JSONArray();
            int start = Math.max(0, a.length() - 50);
            for (int i = start; i < a.length(); i++) out.put(a.get(i));
            prefs.edit().putString("history", out.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private void addBookmarkCurrent() {
        if (web == null || web.getUrl() == null || !web.getUrl().startsWith("http")) return;
        try {
            JSONArray a = loadList("bookmarks");
            for (int i = 0; i < a.length(); i++) {
                if (web.getUrl().equals(a.getJSONObject(i).optString("u"))) {
                    toast(t("আগেই আছে", "Already saved"));
                    return;
                }
            }
            JSONObject o = new JSONObject();
            String n = web.getTitle();
            o.put("n", n == null || n.isEmpty() ? web.getUrl() : n);
            o.put("u", web.getUrl());
            a.put(o);
            prefs.edit().putString("bookmarks", a.toString()).apply();
            toast("⭐ " + t("বুকমার্ক হয়েছে", "Bookmarked"));
        } catch (Exception ignored) {
        }
    }

    private void showUrlList(final String key, String title, final boolean allowAdd) {
        final JSONArray a = loadList(key);
        final int n = a.length();
        if (n == 0) {
            toast(t("খালি", "Empty"));
            return;
        }
        final String[] names = new String[n];
        final String[] urls = new String[n];
        for (int i = 0; i < n; i++) {
            JSONObject o = a.optJSONObject(n - 1 - i);
            names[i] = o == null ? "" : o.optString("n");
            urls[i] = o == null ? "" : o.optString("u");
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle(title)
                .setItems(names, (d, which) -> openSite(urls[which]));
        if (key.equals("history")) {
            b.setNegativeButton(t("মুছুন", "Clear"), (d, w) ->
                    prefs.edit().putString("history", "[]").apply());
        } else {
            b.setNegativeButton(t("মুছুন (সব)", "Clear all"), (d, w) ->
                    prefs.edit().putString("bookmarks", "[]").apply());
        }
        b.show();
    }

    // ------------------------------------------------------------------ menus

    private void showSites() {
        new AlertDialog.Builder(this)
                .setTitle(t("ওয়েব", "Web"))
                .setItems(SITE_NAMES, (d, which) -> {
                    prefs.edit().putString("lastUrl", SITE_URLS[which]).apply();
                    openSite(SITE_URLS[which]);
                })
                .show();
    }

    private void showMore() {
        final Dialog dlg = new Dialog(this);
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(14), dp(12), dp(14));
        box.setBackground(round(cBar, alpha(cAccent, 0x80), 22));
        TextView head = label(APP_TITLE, 16, cAccent, true);
        head.setGravity(Gravity.CENTER);
        head.setPadding(0, 0, 0, dp(8));
        box.addView(head);

        final String[] icons = {"◀", "▶", "🔄", "🏠", "🖥", "🔊", "🔍", "📸", "⭐", "🕘", "📥", "🔗", "📤", "🌐", "⚙"};
        final String[] names = {"Back", "Forward", "Reload", "Messenger",
                desktop ? "Desktop ✓" : "Desktop", "Volume Max", t("খুঁজুন", "Find"),
                t("স্ক্রিনশট", "Screenshot"), t("বুকমার্ক", "Bookmarks"), t("হিস্টরি", "History"),
                t("ডাউনলোড", "Downloads"), t("লিংক কপি", "Copy link"), t("শেয়ার", "Share"),
                t("ব্রাউজার", "Browser"), t("সেটিং", "Settings")};
        LinearLayout row = null;
        for (int i = 0; i < icons.length; i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                box.addView(row);
            }
            final int idx = i;
            row.addView(btn(icons[i] + "\n" + names[i], v -> {
                dlg.dismiss();
                menuAction(idx);
            }), lpW(1f, 4));
        }
        sv.addView(box);
        dlg.setContentView(sv);
        dlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dlg.show();
        dlg.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.94f),
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void menuAction(int which) {
        String cur = web == null || web.getUrl() == null ? "" : web.getUrl();
        switch (which) {
            case 0:
                if (web != null && web.canGoBack()) web.goBack();
                break;
            case 1:
                if (web != null && web.canGoForward()) web.goForward();
                break;
            case 2:
                reloadPage();
                break;
            case 3:
                openSite(SITE_URLS[1]);
                break;
            case 4:
                toggleDesktop();
                break;
            case 5:
                try {
                    AudioManager a = am();
                    a.setStreamVolume(AudioManager.STREAM_MUSIC,
                            a.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
                    a.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                            a.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0);
                } catch (Exception ignored) {
                }
                toast("🔊 Volume Max ✓");
                break;
            case 6:
                findInPage();
                break;
            case 7:
                takeScreenshot();
                break;
            case 8:
                showUrlList("bookmarks", "⭐ " + t("বুকমার্ক", "Bookmarks"), true);
                break;
            case 9:
                showUrlList("history", "🕘 " + t("হিস্টরি", "History"), false);
                break;
            case 10:
                try {
                    startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
                } catch (Exception e) {
                    toast("Cannot open");
                }
                break;
            case 11:
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("link", cur));
                toast(t("লিংক কপি হয়েছে", "Link copied"));
                break;
            case 12:
                Intent sh = new Intent(Intent.ACTION_SEND);
                sh.setType("text/plain");
                sh.putExtra(Intent.EXTRA_TEXT, cur);
                startActivity(Intent.createChooser(sh, "Share"));
                break;
            case 13:
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(cur)));
                } catch (Exception e) {
                    toast("Cannot open");
                }
                break;
            default:
                showPage(4);
                break;
        }
    }

    private void toggleDesktop() {
        desktop = !desktop;
        prefs.edit().putBoolean("desktop", desktop).apply();
        for (Tab tb : tabs) applyUa(tb.web);
        reloadPage();
        toast("Desktop mode: " + (desktop ? "ON" : "OFF"));
    }

    private void findInPage() {
        if (web == null) return;
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("🔍 " + t("পেজে খুঁজুন", "Find in page"))
                .setView(et)
                .setPositiveButton(t("খুঁজুন", "Find"), (d, w) -> {
                    String q = et.getText().toString();
                    if (!q.isEmpty()) web.findAllAsync(q);
                })
                .setNeutralButton(t("পরেরটা", "Next"), (d, w) -> web.findNext(true))
                .setNegativeButton(t("বন্ধ", "Clear"), (d, w) -> web.clearMatches())
                .show();
    }

    private void takeScreenshot() {
        if (web == null || web.getWidth() == 0) return;
        if (Build.VERSION.SDK_INT < 29) {
            toast(t("স্ক্রিনশট Android 10+ এ চলে", "Screenshot needs Android 10+"));
            return;
        }
        try {
            Bitmap bmp = Bitmap.createBitmap(web.getWidth(), web.getHeight(), Bitmap.Config.ARGB_8888);
            web.draw(new Canvas(bmp));
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "DragonMaster_" + System.currentTimeMillis() + ".png");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DragonMaster");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            OutputStream os = getContentResolver().openOutputStream(u);
            bmp.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            toast("📸 " + t("সেভ হয়েছে (Pictures/DragonMaster)", "Saved (Pictures/DragonMaster)"));
        } catch (Exception e) {
            toast("Screenshot failed");
        }
    }

    // ------------------------------------------------------------------ settings page

    private void settingRow(String title, String value, View.OnClickListener l) {
        LinearLayout r = card();
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setClickable(true);
        r.setOnClickListener(l);
        TextView tt = label(title, 15, cText, false);
        r.addView(tt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView vv = label(value, 13, cAccent, true);
        vv.setGravity(Gravity.END);
        r.addView(vv);
        settingsBox.addView(r, lpFull(8));
    }

    private String onOff(boolean b) {
        return b ? "ON ✓" : "OFF";
    }

    private void buildSettings() {
        settingsBox.removeAllViews();
        settingsBox.addView(label("⚙ " + t("সেটিং", "Settings"), 20, cAccent, true));

        settingsBox.addView(section(t("দেখতে", "APPEARANCE")));
        settingRow("🎨 " + t("থিম", "Theme"), THEMES[themeIdx][0], v -> {
            String[] names = new String[THEMES.length];
            for (int i = 0; i < THEMES.length; i++) names[i] = THEMES[i][0];
            new AlertDialog.Builder(this).setTitle(t("থিম", "Theme"))
                    .setItems(names, (d, w) -> {
                        prefs.edit().putInt("theme", w).apply();
                        saveTabs();
                        recreate();
                    }).show();
        });
        settingRow("🌐 " + t("ভাষা", "Language"), bn ? "বাংলা" : "English", v -> {
            prefs.edit().putBoolean("bn", !bn).apply();
            saveTabs();
            recreate();
        });
        settingRow("🔤 " + t("লেখার সাইজ", "Text size"), prefs.getInt("zoom", 100) + "%", v -> {
            new AlertDialog.Builder(this).setTitle(t("লেখার সাইজ", "Text size"))
                    .setItems(new String[]{"90%", "100%", "120%", "140%"}, (d, w) -> {
                        int[] z = {90, 100, 120, 140};
                        prefs.edit().putInt("zoom", z[w]).apply();
                        for (Tab tb : tabs) tb.web.getSettings().setTextZoom(z[w]);
                        buildSettings();
                    }).show();
        });
        settingRow("📱 " + t("স্ক্রিন চালু রাখুন", "Keep screen on"), onOff(prefs.getBoolean("keepOn", true)), v -> {
            prefs.edit().putBoolean("keepOn", !prefs.getBoolean("keepOn", true)).apply();
            applyWindowFlags();
            buildSettings();
        });

        settingsBox.addView(section(t("কল ও সাউন্ড", "CALL & SOUND")));
        int ap = prefs.getInt("autoPreset", -1);
        settingRow("🎛 " + t("কল শুরুতে প্রিসেট", "Preset on call start"),
                ap < 0 ? "Off" : PRESET_NAMES[ap], v -> {
                    new AlertDialog.Builder(this).setTitle(t("অটো প্রিসেট", "Auto preset"))
                            .setItems(new String[]{"Off", PRESET_NAMES[0], PRESET_NAMES[1],
                                    PRESET_NAMES[2], PRESET_NAMES[3]}, (d, w) -> {
                                prefs.edit().putInt("autoPreset", w - 1).apply();
                                buildSettings();
                            }).show();
                });
        settingRow("🖥 Desktop mode", onOff(desktop), v -> {
            toggleDesktop();
            buildSettings();
        });

        settingsBox.addView(section(t("নিরাপত্তা", "SECURITY")));
        boolean hasPin = prefs.getString("pinHash", null) != null;
        settingRow("🔐 " + t("অ্যাপ লক (PIN)", "App lock (PIN)"),
                hasPin ? t("চালু ✓", "ON ✓") : "OFF", v -> pinMenu());
        settingRow("🛡 " + t("স্ক্রিনশট বন্ধ", "Block screenshots"), onOff(prefs.getBoolean("secure", false)), v -> {
            prefs.edit().putBoolean("secure", !prefs.getBoolean("secure", false)).apply();
            applyWindowFlags();
            buildSettings();
        });
        settingRow("🧹 " + t("ক্যাশ ও কুকি মুছুন", "Clear cache & cookies"), "", v -> {
            new AlertDialog.Builder(this).setTitle(t("নিশ্চিত?", "Sure?"))
                    .setMessage(t("সব ওয়েবে আবার লগইন করতে হবে।", "You will have to log in again."))
                    .setPositiveButton(t("হ্যাঁ", "Yes"), (d, w) -> {
                        for (Tab tb : tabs) tb.web.clearCache(true);
                        CookieManager.getInstance().removeAllCookies(null);
                        CookieManager.getInstance().flush();
                        WebStorage.getInstance().deleteAllData();
                        reloadPage();
                        toast("✓");
                    }).setNegativeButton(t("না", "No"), null).show();
        });

        settingsBox.addView(section(t("ব্যাকআপ", "BACKUP")));
        settingRow("💾 " + t("সেটিং ব্যাকআপ", "Backup settings"), "", v -> backupSettings());
        settingRow("♻ " + t("সেটিং রিস্টোর", "Restore settings"), "", v -> restoreSettings());

        settingsBox.addView(section(t("অ্যাপ", "APP")));
        settingRow("ℹ " + t("সম্পর্কে", "About"), "v2.0", v -> {
            new AlertDialog.Builder(this).setTitle(APP_TITLE + " v2.0")
                    .setMessage(APP_SUB + "\nMic boost • Call sound boost • Mixer • Tabs • App lock\nBy Mahir")
                    .setPositiveButton("OK", null).show();
        });
    }

    private void backupSettings() {
        try {
            JSONObject o = new JSONObject();
            o.put("store", new JSONObject(storeJson()));
            o.put("theme", themeIdx);
            o.put("bn", bn);
            o.put("zoom", prefs.getInt("zoom", 100));
            o.put("autoPreset", prefs.getInt("autoPreset", -1));
            o.put("desktop", desktop);
            o.put("bookmarks", loadList("bookmarks"));
            final String json = o.toString();
            new AlertDialog.Builder(this).setTitle("💾 Backup")
                    .setMessage(json)
                    .setPositiveButton("Copy", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("dragon-backup", json));
                        toast(t("কপি হয়েছে — কোথাও সেভ করে রাখুন", "Copied - save it somewhere"));
                    })
                    .setNegativeButton("Close", null).show();
        } catch (Exception e) {
            toast("Backup failed");
        }
    }

    private void restoreSettings() {
        final EditText et = new EditText(this);
        et.setHint("{ ... }");
        new AlertDialog.Builder(this).setTitle("♻ Restore")
                .setMessage(t("ব্যাকআপের লেখা এখানে পেস্ট করুন", "Paste your backup text here"))
                .setView(et)
                .setPositiveButton("Restore", (d, w) -> {
                    try {
                        JSONObject o = new JSONObject(et.getText().toString().trim());
                        SharedPreferences.Editor ed = prefs.edit();
                        if (o.has("store")) ed.putString("store", o.getJSONObject("store").toString());
                        if (o.has("theme")) ed.putInt("theme", o.getInt("theme"));
                        if (o.has("bn")) ed.putBoolean("bn", o.getBoolean("bn"));
                        if (o.has("zoom")) ed.putInt("zoom", o.getInt("zoom"));
                        if (o.has("autoPreset")) ed.putInt("autoPreset", o.getInt("autoPreset"));
                        if (o.has("desktop")) ed.putBoolean("desktop", o.getBoolean("desktop"));
                        if (o.has("bookmarks")) ed.putString("bookmarks", o.getJSONArray("bookmarks").toString());
                        ed.apply();
                        saveTabs();
                        recreate();
                    } catch (Exception e) {
                        toast(t("ব্যাকআপ ঠিক নেই", "Invalid backup"));
                    }
                })
                .setNegativeButton("Cancel", null).show();
    }

    // ------------------------------------------------------------------ app lock

    private String hashPin(String pin) {
        try {
            String salt = prefs.getString("pinSalt", "");
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((salt + pin).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : h) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void pinMenu() {
        final boolean hasPin = prefs.getString("pinHash", null) != null;
        String[] items = hasPin
                ? new String[]{t("PIN বদলান", "Change PIN"), t("লক বন্ধ করুন", "Remove lock")}
                : new String[]{t("PIN সেট করুন", "Set PIN")};
        new AlertDialog.Builder(this).setTitle("🔐 App lock")
                .setItems(items, (d, w) -> {
                    if (hasPin && w == 1) {
                        prefs.edit().remove("pinHash").remove("pinSalt").remove("pinLen").apply();
                        buildSettings();
                    } else {
                        setPinDialog();
                    }
                }).show();
    }

    private void setPinDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        et.setHint("4-6 digits");
        new AlertDialog.Builder(this).setTitle(t("নতুন PIN (৪-৬ সংখ্যা)", "New PIN (4-6 digits)"))
                .setView(et)
                .setPositiveButton("OK", (d, w) -> {
                    String p = et.getText().toString().trim();
                    if (p.length() < 4 || p.length() > 6) {
                        toast(t("৪ থেকে ৬ সংখ্যা দিন", "Use 4 to 6 digits"));
                        return;
                    }
                    String salt = Long.toString(new Random().nextLong(), 36);
                    prefs.edit().putString("pinSalt", salt).apply();
                    prefs.edit().putString("pinHash", hashPin(p)).putInt("pinLen", p.length()).apply();
                    toast("🔐 ✓");
                    buildSettings();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void buildLock() {
        lockView = new FrameLayout(this);
        lockView.setBackgroundColor(cBg);
        lockView.setClickable(true);
        lockView.setVisibility(View.GONE);

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.ic_launcher);
        l.addView(iv, new LinearLayout.LayoutParams(dp(72), dp(72)));
        TextView n = label(APP_TITLE, 20, cAccent, true);
        n.setPadding(0, dp(10), 0, dp(2));
        l.addView(n);
        lockMsg = label(t("PIN দিন", "Enter PIN"), 14, cDim, false);
        l.addView(lockMsg);
        lockDots = label("", 28, cAccent, true);
        lockDots.setPadding(0, dp(12), 0, dp(16));
        l.addView(lockDots);

        String[][] keys = {{"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"}, {"", "0", "⌫"}};
        for (String[] kr : keys) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER);
            for (final String k : kr) {
                if (k.isEmpty()) {
                    row.addView(new View(this), new LinearLayout.LayoutParams(dp(76), dp(76)));
                    continue;
                }
                TextView kb = btn(k, v -> keyPress(k));
                kb.setTextSize(22);
                LinearLayout.LayoutParams kp = new LinearLayout.LayoutParams(dp(76), dp(76));
                kp.setMargins(dp(6), dp(6), dp(6), dp(6));
                row.addView(kb, kp);
            }
            l.addView(row);
        }
        lockView.addView(l, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(lockView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showLock() {
        pinBuf.setLength(0);
        updateDots();
        lockMsg.setText(t("PIN দিন", "Enter PIN"));
        lockView.setVisibility(View.VISIBLE);
        lockView.bringToFront();
    }

    private void updateDots() {
        int len = prefs.getInt("pinLen", 4);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) sb.append(i < pinBuf.length() ? "● " : "○ ");
        lockDots.setText(sb.toString().trim());
    }

    private void keyPress(String k) {
        if (System.currentTimeMillis() < lockUntil) {
            lockMsg.setText(t("একটু অপেক্ষা করুন...", "Please wait..."));
            return;
        }
        int len = prefs.getInt("pinLen", 4);
        if (k.equals("⌫")) {
            if (pinBuf.length() > 0) pinBuf.setLength(pinBuf.length() - 1);
        } else if (pinBuf.length() < len) {
            pinBuf.append(k);
        }
        updateDots();
        if (pinBuf.length() == len) {
            String h = prefs.getString("pinHash", "");
            if (hashPin(pinBuf.toString()).equals(h)) {
                wrongCount = 0;
                lockView.setVisibility(View.GONE);
            } else {
                wrongCount++;
                pinBuf.setLength(0);
                updateDots();
                if (wrongCount >= 3) {
                    wrongCount = 0;
                    lockUntil = System.currentTimeMillis() + 30000;
                    lockMsg.setText(t("৩ বার ভুল — ৩০ সেকেন্ড অপেক্ষা", "3 wrong tries - wait 30s"));
                } else {
                    lockMsg.setText(t("ভুল PIN", "Wrong PIN"));
                }
            }
        }
    }

    // ------------------------------------------------------------------ permissions + audio

    private boolean hasPerm(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void handlePermission(PermissionRequest req) {
        String origin = req.getOrigin() == null ? "" : req.getOrigin().toString();
        if (!origin.startsWith("file:") && !hostAllowed(origin)) {
            req.deny();
            return;
        }
        List<String> need = new ArrayList<String>();
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !hasPerm(Manifest.permission.RECORD_AUDIO)) {
                need.add(Manifest.permission.RECORD_AUDIO);
            }
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !hasPerm(Manifest.permission.CAMERA)) {
                need.add(Manifest.permission.CAMERA);
            }
        }
        if (need.isEmpty()) {
            grant(req, origin);
        } else {
            pendingRequest = req;
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    private void grant(PermissionRequest req, String origin) {
        boolean audio = false;
        for (String r : req.getResources()) {
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
        }
        try {
            req.grant(req.getResources());
        } catch (Exception ignored) {
        }
        // only real web calls count as a call (not the mixer/mic panels)
        if (audio && !origin.startsWith("file:")) callStarted();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM && pendingRequest != null) {
            PermissionRequest r = pendingRequest;
            pendingRequest = null;
            boolean any = false;
            for (int g : results) if (g == PackageManager.PERMISSION_GRANTED) any = true;
            if (any) {
                String o = r.getOrigin() == null ? "" : r.getOrigin().toString();
                grant(r, o);
            } else {
                r.deny();
            }
        }
    }

    private void startCallAudio() {
        try {
            am();
            if (Build.VERSION.SDK_INT >= 26) {
                if (focusRequest == null) {
                    focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build())
                            .setOnAudioFocusChangeListener(focusListener)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                audioManager.requestAudioFocus(focusRequest);
            } else {
                audioManager.requestAudioFocus(focusListener, AudioManager.STREAM_VOICE_CALL,
                        AudioManager.AUDIOFOCUS_GAIN);
            }
        } catch (Exception ignored) {
        }
    }

    private void resumeCallAudio() {
        runInMain("window.__ssResume&&window.__ssResume();");
    }

    // ------------------------------------------------------------------ media library

    private String kindOf(String name) {
        String n = name.toLowerCase();
        String[] vid = {".mp4", ".mkv", ".mov", ".3gp", ".webm"};
        for (String v : vid) if (n.endsWith(v)) return "video";
        return "audio";
    }

    private JSONArray libJson() {
        JSONArray a = new JSONArray();
        File[] fs = mixDir.listFiles();
        if (fs == null) return a;
        Arrays.sort(fs, new Comparator<File>() {
            @Override
            public int compare(File x, File y) {
                return Long.compare(x.lastModified(), y.lastModified());
            }
        });
        for (File f : fs) {
            String n = f.getName();
            int i = n.indexOf("__");
            if (i <= 0) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("id", n.substring(0, i));
                o.put("name", n.substring(i + 2));
                o.put("kind", kindOf(n));
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        return a;
    }

    private File findMedia(String id) {
        if (id == null || !id.matches("[a-z0-9]+")) return null;
        File[] fs = mixDir.listFiles();
        if (fs == null) return null;
        for (File f : fs) if (f.getName().startsWith(id + "__")) return f;
        return null;
    }

    private String mediaInfo(String id) {
        File f = findMedia(id);
        return "{\"size\":" + (f == null ? 0 : f.length()) + "}";
    }

    private String mediaChunk(String id, int idx) {
        File f = findMedia(id);
        if (f == null) return "";
        try {
            RandomAccessFile r = new RandomAccessFile(f, "r");
            long off = (long) idx * CHUNK;
            if (off >= r.length()) {
                r.close();
                return "";
            }
            int len = (int) Math.min((long) CHUNK, r.length() - off);
            byte[] buf = new byte[len];
            r.seek(off);
            r.readFully(buf);
            r.close();
            return Base64.encodeToString(buf, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private void notifyLibChanged() {
        final String items = libJson().toString();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (web != null) {
                    web.evaluateJavascript("window.__ssMixer&&window.__ssMixer.cmd({t:'lib',items:" + items + "})", null);
                }
                if (micPanel != null) {
                    micPanel.evaluateJavascript("window.onLibChanged&&window.onLibChanged()", null);
                }
                if (mixerPanel != null) {
                    mixerPanel.evaluateJavascript("window.onLibChanged&&window.onLibChanged()", null);
                }
            }
        });
    }

    private void importMedia(final Uri u) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = "file";
                long size = -1;
                Cursor c = null;
                try {
                    c = getContentResolver().query(u, null, null, null, null);
                    if (c != null && c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        int si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0) name = c.getString(ni);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } catch (Exception ignored) {
                } finally {
                    if (c != null) c.close();
                }
                if (size > MAX_MEDIA_BYTES) {
                    toast(name + " - file is too big (max 40 MB)");
                    return;
                }
                name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                String id = Long.toString(Math.abs(System.nanoTime()), 36)
                        + Integer.toString(new Random().nextInt(1296), 36);
                File out = new File(mixDir, id + "__" + name);
                try {
                    InputStream in = getContentResolver().openInputStream(u);
                    OutputStream os = new FileOutputStream(out);
                    byte[] buf = new byte[65536];
                    long total = 0;
                    int n;
                    boolean tooBig = false;
                    while (in != null && (n = in.read(buf)) > 0) {
                        total += n;
                        if (total > MAX_MEDIA_BYTES) {
                            tooBig = true;
                            break;
                        }
                        os.write(buf, 0, n);
                    }
                    os.close();
                    if (in != null) in.close();
                    if (tooBig) {
                        out.delete();
                        toast(name + " - file is too big (max 40 MB)");
                        return;
                    }
                } catch (Exception e) {
                    out.delete();
                    toast("Import failed");
                    return;
                }
                notifyLibChanged();
            }
        }).start();
    }

    private void pickMediaFiles() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "audio/*", "video/*", "application/zip",
                "application/x-zip-compressed", "application/octet-stream"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "Audio / Video / ZIP"), REQ_MEDIA);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE) {
            if (pendingFile != null) {
                Uri[] r = null;
                if (res == Activity.RESULT_OK && data != null) {
                    r = WebChromeClient.FileChooserParams.parseResult(res, data);
                }
                pendingFile.onReceiveValue(r);
                pendingFile = null;
            }
        } else if (req == REQ_MEDIA && res == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    importMedia(data.getClipData().getItemAt(i).getUri());
                }
            } else if (data.getData() != null) {
                importMedia(data.getData());
            }
        }
    }

    // ------------------------------------------------------------------ JS bridges

    private String storeJson() {
        return prefs.getString("store", "{}");
    }

    /** Used by the web pages (Messenger, Facebook ...). */
    public class MainBridge {
        @JavascriptInterface
        public String getConfig() {
            try {
                JSONObject st = new JSONObject(storeJson());
                JSONObject cfg = st.optJSONObject("micMaximizerConfig");
                return cfg == null ? "{}" : cfg.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void ready() {
            lastReady = System.currentTimeMillis();
        }

        @JavascriptInterface
        public String listMedia() {
            return libJson().toString();
        }

        @JavascriptInterface
        public String mediaInfo(String id) {
            return MainActivity.this.mediaInfo(id);
        }

        @JavascriptInterface
        public String mediaChunk(String id, int idx) {
            return MainActivity.this.mediaChunk(id, idx);
        }

        @JavascriptInterface
        public void mixerState(String json) {
            if (json != null) mixerState = json;
        }
    }

    /** Used by the Mic / Mixer panel pages. */
    public class PanelBridge {
        @JavascriptInterface
        public String getStore() {
            return storeJson();
        }

        @JavascriptInterface
        public void setStore(String s) {
            prefs.edit().putString("store", s == null ? "{}" : s).apply();
            runInMain("window.__ssPush&&window.__ssPush();");
        }

        @JavascriptInterface
        public String lastReady() {
            return String.valueOf(lastReady);
        }

        @JavascriptInterface
        public void mixerCmd(String json) {
            runInMain("window.__ssMixer&&window.__ssMixer.cmd(" + json + ")");
        }

        @JavascriptInterface
        public String getMixerState() {
            return mixerState;
        }

        @JavascriptInterface
        public String listMedia() {
            return libJson().toString();
        }

        @JavascriptInterface
        public String mediaInfo(String id) {
            return MainActivity.this.mediaInfo(id);
        }

        @JavascriptInterface
        public String mediaChunk(String id, int idx) {
            return MainActivity.this.mediaChunk(id, idx);
        }

        @JavascriptInterface
        public String fileUrl(String id) {
            File f = findMedia(id);
            return f == null ? "" : "file://" + f.getAbsolutePath();
        }

        @JavascriptInterface
        public void deleteMedia(String id) {
            File f = findMedia(id);
            if (f != null) f.delete();
            notifyLibChanged();
        }

        @JavascriptInterface
        public void pickFiles() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pickMediaFiles();
                }
            });
        }
    }
}
